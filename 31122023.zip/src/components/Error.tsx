const Error = () => {
    return (
        <div>
            <h1>Error vvv</h1>
        </div>
    );
};

export default Error;
