    const config = {
        API_BASE_URL : "http://localhost:8081/api"
    }

    export default  config
